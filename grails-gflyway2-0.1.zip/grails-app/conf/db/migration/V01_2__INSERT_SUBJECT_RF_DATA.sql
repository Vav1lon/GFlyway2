BEGIN;

ALTER TABLE subject_rf
DROP CONSTRAINT SUBJECT_RF_DIVISION_FK;

INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (16, 'Республика Адыгея', 3, 1);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (6, 'Республика Башкортостан', 5, 2);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (5, 'Республика Бурятия', 7, 3);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (22, 'Республика Алтай', 7, 4);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (18, 'Республика Дагестан', 4, 5);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (18, 'Республика Ингушетия', 4, 6);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (18, 'Кабардино-Балкарская республика', 4, 7);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (9, 'Республика Калмыкия', 3, 8);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (18, 'Карачаево-Черкесская республика', 4, 9);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (15, 'Республика Карелия', 2, 10);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (10, 'Республика Коми', 2, 11);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (11, 'Республика Марий Эл', 5, 12);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (2, 'Республика Мордовия', 5, 13);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (7, 'Республика Саха (Якутия)', 8, 14);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (18, 'Республика Северная Осетия — Алания', 4, 15);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (11, 'Республика Татарстан', 5, 16);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (4, 'Республика Тыва', 7, 17);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (6, 'Удмуртская республика', 5, 18);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (4, 'Республика Хакасия', 7, 19);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (18, 'Чеченская республика', 4, 20);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (11, 'Чувашская республика', 5, 21);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (22, 'Алтайский край', 7, 22);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (16, 'Краснодарский край', 3, 23);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (4, 'Красноярский край', 7, 24);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (3, 'Приморский край', 8, 25);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (18, 'Ставропольский край', 4, 26);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (3, 'Хабаровский край', 8, 27);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (3, 'Амурская область', 8, 28);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (15, 'Архангельская область', 2, 29);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (9, 'Астраханская область', 3, 30);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (1, 'Белгородская область', 1, 31);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (12, 'Брянская область', 1, 32);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (5, 'Владимирская область', 1, 33);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (9, 'Волгоградская область', 3, 34);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (15, 'Вологодская область', 2, 35);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (1, 'Воронежская область', 1, 36);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (21, 'Ивановская область', 1, 37);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (4, 'Иркутская область', 7, 38);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (21, 'Калининградская область', 2, 39);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (12, 'Калужская область', 1, 40);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (3, 'Камчатский край', 8, 41);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (22, 'Кемеровская область', 7, 42);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (6, 'Кировская область', 5, 43);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (21, 'Костромская область', 1, 44);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (20, 'Курганская область', 6, 45);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (1, 'Курская область', 1, 46);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (15, 'Ленинградская область', 2, 47);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (1, 'Липецкая область', 1, 48);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (14, 'Магаданская область', 8, 49);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (21, 'Московская область', 1, 50);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (15, 'Мурманская область', 2, 51);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (2, 'Нижегородская область', 5, 52);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (15, 'Новгородская область', 2, 53);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (22, 'Новосибирская область', 7, 54);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (22, 'Омская область', 7, 55);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (6, 'Оренбургская область', 5, 56);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (12, 'Орловская область', 1, 57);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (9, 'Пензенская область', 5, 58);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (6, 'Пермский край', 5, 59);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (15, 'Псковская область', 2, 60);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (16, 'Ростовская область', 3, 61);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (12, 'Рязанская область', 1, 62);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (19, 'Самарская область', 5, 63);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (9, 'Саратовская область', 5, 64);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (13, 'Сахалинская область', 8, 65);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (20, 'Свердловская область', 6, 66);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (21, 'Смоленская область', 1, 67);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (1, 'Тамбовская область', 1, 68);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (21, 'Тверская область', 1, 69);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (22, 'Томская область', 7, 70);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (12, 'Тульская область', 1, 71);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (17, 'Тюменская область', 6, 72);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (19, 'Ульяновская область', 5, 73);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (20, 'Челябинская область', 6, 74);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (5, 'Забайкальский край', 7, 75);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (21, 'Ярославская область', 1, 76);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (8, 'Москва', 1, 77);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (15, 'Санкт-Петербург', 2, 78);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (3, 'Еврейская автономная область', 8, 79);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (10, 'Ненецкий автономный округ', 2, 83);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (17, 'Ханты-Мансийский автономный округ - Югра', 6, 86);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (8, 'Чукотский автономный округ', 8, 87);
INSERT INTO subject_rf (division_id, name, federal_district, code) VALUES (17, 'Ямало-Ненецкий автономный округ', 6, 89);

UPDATE subject_rf srf
  SET division_id = dv.id
  FROM division dv
  WHERE srf.division_id = dv.code;

ALTER TABLE subject_rf
  ADD CONSTRAINT SUBJECT_RF_DIVISION_FK
  FOREIGN KEY (division_id)
  REFERENCES division;

COMMIT;