ALTER TABLE district ALTER COLUMN sub_rf_code DROP NOT NULL;
ALTER TABLE district ALTER COLUMN subjectrf_id DROP NOT NULL;

UPDATE district SET sub_rf_code = NULL, subjectrf_id = NULL WHERE division_id IS NOT NULL;

UPDATE district d SET division_id = (SELECT srf.division_id FROM subject_rf srf WHERE srf.id = d.subjectrf_id) WHERE d.division_id IS NULL;

ALTER TABLE district ALTER COLUMN division_id SET NOT NULL;


UPDATE employee e SET district_id = (SELECT me.district_id FROM municipal_entry me WHERE e.municipal_entry_id = me.id) WHERE e.district_id IS NULL AND e.municipal_entry_id IS NOT NULL;

UPDATE employee e SET division_id = (SELECT d.division_id FROM district d WHERE e.district_id = d.id) WHERE e.division_id IS NULL AND e.district_id IS NOT NULL;
