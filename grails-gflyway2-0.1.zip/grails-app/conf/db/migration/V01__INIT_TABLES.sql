BEGIN;

CREATE SEQUENCE checklist_seq;
CREATE SEQUENCE district_seq;
CREATE SEQUENCE division_seq;
CREATE SEQUENCE employee_seq;
CREATE SEQUENCE municipal_entry_seq;
CREATE SEQUENCE reporting_period_seq;
CREATE SEQUENCE role_seq;
CREATE SEQUENCE subject_rf_seq;
CREATE SEQUENCE upload_file_seq;

CREATE TABLE checklist (
    id         INT8         NOT NULL DEFAULT nextval('checklist_seq')
  , item_order VARCHAR(255) NOT NULL
  , name       VARCHAR(255) NOT NULL
  , note       VARCHAR(255)
  , onlyrtn    BOOL         NOT NULL
  , period_id  INT8         NOT NULL
  , PRIMARY KEY (id)
);

CREATE TABLE district (
    id           INT8         NOT NULL DEFAULT nextval('district_seq')
  , code         VARCHAR(8)   NOT NULL
  , division_id  INT8
  , name         VARCHAR(255) NOT NULL
  , sub_rf_code  INT4         NOT NULL
  , subjectrf_id INT8         NOT NULL
  , type         INT4         NOT NULL
  , PRIMARY KEY (id)
);

CREATE TABLE division (
    id   INT8         NOT NULL DEFAULT nextval('division_seq')
  , code INT4         NOT NULL
  , name VARCHAR(255) NOT NULL
  , PRIMARY KEY (id)
);

CREATE TABLE employee (
    id                 INT8         NOT NULL DEFAULT nextval('employee_seq')
  , account_expired    BOOL         NOT NULL
  , account_locked     BOOL         NOT NULL
  , date_created       TIMESTAMP    NOT NULL
  , district_id        INT8
  , division_id        INT8
  , enabled            BOOL         NOT NULL
  , last_updated       TIMESTAMP    NOT NULL
  , municipal_entry_id INT8
  , "password"         VARCHAR(255) NOT NULL
  , password_expired   BOOL         NOT NULL
  , username           VARCHAR(255) NOT NULL UNIQUE
  , firstname          VARCHAR(255)
  , secondname         VARCHAR(255)
  , lastname           VARCHAR(255)
  , PRIMARY KEY (id)
);

CREATE TABLE employee_authorities (
    role_id         INT8 NOT NULL
  , employee_id     INT8 NOT NULL
  , authorities_idx INT4 NOT NULL
  , PRIMARY KEY (role_id, employee_id)
);

CREATE TABLE municipal_entry (
    id            INT8         NOT NULL DEFAULT nextval('municipal_entry_seq')
  , code          VARCHAR(8)   NOT NULL
  , district_id   INT8
  , name          VARCHAR(255) NOT NULL
  , district_code VARCHAR(8)   NOT NULL
  , type          INT4         NOT NULL
  , PRIMARY KEY (id)
);

CREATE TABLE reporting_period (
    id           INT8      NOT NULL DEFAULT nextval('reporting_period_seq')
  , active       BOOL      NOT NULL
  , begin_year   INT4      NOT NULL
  , date_created TIMESTAMP NOT NULL
  , end_year     INT4      NOT NULL
  , last_updated TIMESTAMP NOT NULL
  , PRIMARY KEY (id)
);

CREATE TABLE role (
    id        INT8         NOT NULL DEFAULT nextval('role_seq')
  , authority VARCHAR(255) NOT NULL UNIQUE
  , PRIMARY KEY (id)
);

CREATE TABLE subject_rf (
    id               INT8         NOT NULL DEFAULT nextval('subject_rf_seq')
  , code             INT4         NOT NULL
  , division_id      INT8         NOT NULL
  , federal_district INT4         NOT NULL
  , name             VARCHAR(255) NOT NULL
  , PRIMARY KEY (id)
);

CREATE TABLE upload_file (
    id           INT8         NOT NULL DEFAULT nextval('upload_file_seq')
  , date_created TIMESTAMP    NOT NULL
  , employee_id  INT8
  , extension    VARCHAR(255) NOT NULL
  , guid         VARCHAR(255) NOT NULL
  , last_updated TIMESTAMP    NOT NULL
  , name         VARCHAR(255) NOT NULL
  , path         VARCHAR(255) NOT NULL
  , period_id    INT8         NOT NULL
  , PRIMARY KEY (id)
);

CREATE TABLE upload_file_checklists (
    upload_file_id INT8 NOT NULL
  , checklist_id   INT8 NOT NULL
  , PRIMARY KEY (upload_file_id, checklist_id)
);

CREATE TABLE district_files (
    district_id    INT8
  , upload_file_id INT8
);

CREATE TABLE division_files (
    division_id    INT8
  , upload_file_id INT8
);

CREATE TABLE municipal_entry_files (
    municipal_entry_id INT8
  , upload_file_id     INT8
);

CREATE TABLE subject_rf_files (
    subjectrf_id   INT8
  , upload_file_id INT8
);

CREATE INDEX checklist_period_idx ON checklist (period_id);
CREATE INDEX district_subject_rf_idx ON district (subjectrf_id);
CREATE INDEX employee_municipal_entry_idx ON employee (municipal_entry_id);
CREATE INDEX employee_municipal_division_idx ON employee (division_id);
CREATE INDEX employee_municipal_district_idx ON employee (district_id);
CREATE INDEX municipal_entry_district_idx ON municipal_entry (district_id);
CREATE INDEX subjectrf_division_idx ON subject_rf (division_id);
CREATE INDEX upload_file_employee_idx ON upload_file (employee_id);

ALTER TABLE checklist
ADD CONSTRAINT CHECKLIST_REPORTING_PERIOD_FK
FOREIGN KEY (period_id)
REFERENCES reporting_period;

ALTER TABLE district
ADD CONSTRAINT DISTRICT_DIVISION_FK
FOREIGN KEY (division_id)
REFERENCES division;

ALTER TABLE district
ADD CONSTRAINT DISTRICT_SUBJECT_RF_FK
FOREIGN KEY (subjectrf_id)
REFERENCES subject_rf;

ALTER TABLE employee
ADD CONSTRAINT EMPLOYEE_MUNICIPAL_ENTRY_FK
FOREIGN KEY (municipal_entry_id)
REFERENCES municipal_entry;

ALTER TABLE employee
ADD CONSTRAINT EMPLOYEE_DIVISION_FK
FOREIGN KEY (division_id)
REFERENCES division;

ALTER TABLE employee
ADD CONSTRAINT EMPLOYEE_DISTRICT_FK
FOREIGN KEY (district_id)
REFERENCES district;

ALTER TABLE subject_rf
ADD CONSTRAINT SUBJECT_RF_DIVISION_FK
FOREIGN KEY (division_id)
REFERENCES division;

ALTER TABLE upload_file
ADD CONSTRAINT UPLOAD_FILE_REPORTING_PERIOD_FK
FOREIGN KEY (period_id)
REFERENCES reporting_period;

ALTER TABLE upload_file
ADD CONSTRAINT UPLOAD_FILE_EMPLOYEE_FK
FOREIGN KEY (employee_id)
REFERENCES employee;

ALTER TABLE employee_authorities
ADD CONSTRAINT EMPLOYEE_AUTHORITIES_ROLE_FK
FOREIGN KEY (role_id)
REFERENCES role;

ALTER TABLE employee_authorities
ADD CONSTRAINT EMPLOYEE_AUTHORITIES_EMPLOYEE_FK
FOREIGN KEY (employee_id)
REFERENCES employee;

ALTER TABLE district_files
ADD CONSTRAINT DISTRICT_UPLOAD_FILE_UPLOAD_FILE_FK
FOREIGN KEY (upload_file_id)
REFERENCES upload_file;

ALTER TABLE district_files
ADD CONSTRAINT DISTRICT_UPLOAD_FILE_DISTRICT_FK
FOREIGN KEY (district_id)
REFERENCES district;

ALTER TABLE division_files
ADD CONSTRAINT DIVISION_UPLOAD_FILE_DIVISION_FK
FOREIGN KEY (division_id)
REFERENCES division;

ALTER TABLE division_files
ADD CONSTRAINT DIVISION_UPLOAD_FILE_UPLOAD_FILE_FK
FOREIGN KEY (upload_file_id)
REFERENCES upload_file;

ALTER TABLE municipal_entry_files
ADD CONSTRAINT MUNICIPAL_ENTRY_UPLOAD_FILE_MUNICIPAL_ENTRY_FK
FOREIGN KEY (municipal_entry_id)
REFERENCES municipal_entry;

ALTER TABLE municipal_entry_files
ADD CONSTRAINT MUNICIPAL_ENTRY_UPLOAD_FILE_UPLOAD_FILE_FK
FOREIGN KEY (upload_file_id)
REFERENCES upload_file;

ALTER TABLE subject_rf_files
ADD CONSTRAINT SUBJECT_RF_UPLOAD_FILE_SUBJECT_RF_FK
FOREIGN KEY (subjectrf_id)
REFERENCES subject_rf;

ALTER TABLE subject_rf_files
ADD CONSTRAINT SUBJECT_RF_UPLOAD_FILE_UPLOAD_FILE_FK
FOREIGN KEY (upload_file_id)
REFERENCES upload_file;

ALTER TABLE upload_file_checklists
ADD CONSTRAINT UPLOAD_FILE_CHECKLIST_CHECKLIST_FK
FOREIGN KEY (checklist_id)
REFERENCES checklist;

ALTER TABLE upload_file_checklists
ADD CONSTRAINT UPLOAD_FILE_CHECKLIST_UPLOAD_FILE_FK
FOREIGN KEY (upload_file_id)
REFERENCES upload_file;

COMMIT;