INSERT INTO role (authority) VALUES ('ROLE_ADMIN');
INSERT INTO role (authority) VALUES ('ROLE_RTN_CA');
INSERT INTO role (authority) VALUES ('ROLE_RTN');
INSERT INTO role (authority) VALUES ('ROLE_ADVANCED_RTN');
INSERT INTO role (authority) VALUES ('ROLE_MP');
INSERT INTO role (authority) VALUES ('ROLE_MO');

-- Test users
INSERT INTO employee (account_expired, account_locked, date_created, district_id, division_id, enabled, last_updated, municipal_entry_id, "password", password_expired, username, firstname, secondname, lastname)
  VALUES (FALSE, FALSE, current_timestamp, NULL, NULL, TRUE, current_timestamp, NULL, 'admin123q', FALSE, 'admin', 'Админ', 'Админович', 'Админов');
--INSERT INTO employee (account_expired, account_locked, date_created, district_id, division_id, enabled, last_updated, municipal_entry_id, "password", password_expired, username, firstname, secondname, lastname)
--  VALUES (FALSE, FALSE, current_timestamp, NULL, NULL, TRUE, current_timestamp, NULL, 'user_ca', FALSE, 'user_ca', 'Владимир', 'Владимирович', 'Апаратов');
--INSERT INTO employee (account_expired, account_locked, date_created, district_id, division_id, enabled, last_updated, municipal_entry_id, "password", password_expired, username, firstname, secondname, lastname)
--  VALUES (FALSE, FALSE, current_timestamp, NULL, 21, TRUE, current_timestamp, NULL, 'user_rtn', FALSE, 'user_rtn', 'Соломон', 'Моисеевич', 'Департман');
--INSERT INTO employee (account_expired, account_locked, date_created, district_id, division_id, enabled, last_updated, municipal_entry_id, "password", password_expired, username, firstname, secondname, lastname)
--  VALUES (FALSE, FALSE, current_timestamp, NULL, 21, TRUE, current_timestamp, NULL, 'user_artn', FALSE, 'user_artn', 'Соломон', 'Моисеевич', 'Департман');
--INSERT INTO employee (account_expired, account_locked, date_created, district_id, division_id, enabled, last_updated, municipal_entry_id, "password", password_expired, username, firstname, secondname, lastname)
--  VALUES (FALSE, FALSE, current_timestamp, 2362, null, TRUE, current_timestamp, NULL, 'user_mp', FALSE, 'user_mp', 'Адольф', 'Пантелеевич', 'Тверской');
--INSERT INTO employee (account_expired, account_locked, date_created, district_id, division_id, enabled, last_updated, municipal_entry_id, "password", password_expired, username, firstname, secondname, lastname)
--  VALUES (FALSE, FALSE, current_timestamp, null, null, TRUE, current_timestamp, 8705, 'user_mo', FALSE, 'user_mo', 'Чубакка', null, null);


INSERT INTO employee_authorities (employee_id, role_id, authorities_idx) VALUES ((SELECT
                                                                                    id
                                                                                  FROM employee
                                                                                  WHERE username = 'admin'), (SELECT
                                                                                                                  id
                                                                                                                FROM
                                                                                                                  role
                                                                                                                WHERE
                                                                                                                  authority
                                                                                                                  =
                                                                                                                  'ROLE_ADMIN'), 0);

--INSERT INTO employee_authorities (employee_id, role_id, authorities_idx) VALUES ((SELECT
--                                                                                    id
--                                                                                  FROM employee
--                                                                                  WHERE username = 'user_ca'), (SELECT
--                                                                                                                  id
--                                                                                                                FROM
--                                                                                                                  role
--                                                                                                                WHERE
--                                                                                                                  authority
--                                                                                                                  =
--                                                                                                                  'ROLE_RTN_CA'), 0);
--INSERT INTO employee_authorities (employee_id, role_id, authorities_idx) VALUES ((SELECT
--                                                                                    id
--                                                                                  FROM employee
--                                                                                  WHERE username = 'user_rtn'), (SELECT
--                                                                                                                   id
--                                                                                                                 FROM
--                                                                                                                   role
--                                                                                                                 WHERE
--                                                                                                                   authority
--                                                                                                                   =
--                                                                                                                   'ROLE_RTN'), 0);
--INSERT INTO employee_authorities (employee_id, role_id, authorities_idx) VALUES ((SELECT
--                                                                                    id
--                                                                                  FROM employee
--                                                                                  WHERE username = 'user_artn'), (SELECT
--                                                                                                                   id
--                                                                                                                 FROM
--                                                                                                                   role
--                                                                                                                 WHERE
--                                                                                                                   authority
--                                                                                                                   =
--                                                                                                                   'ROLE_ADVANCED_RTN'), 0);
--INSERT INTO employee_authorities (employee_id, role_id, authorities_idx) VALUES ((SELECT
--                                                                                    id
--                                                                                  FROM employee
--                                                                                  WHERE username = 'user_mp'), (SELECT
--                                                                                                                  id
--                                                                                                                FROM
--                                                                                                                  role
--                                                                                                                WHERE
--                                                                                                                  authority
--                                                                                                                  =
--                                                                                                                  'ROLE_MP'), 0);
--INSERT INTO employee_authorities (employee_id, role_id, authorities_idx) VALUES ((SELECT
--                                                                                    id
--                                                                                  FROM employee
--                                                                                  WHERE username = 'user_mo'), (SELECT
--                                                                                                                  id
--                                                                                                                FROM
--                                                                                                                  role
--                                                                                                                WHERE
--                                                                                                                  authority
--                                                                                                                  =
--                                                                                                                  'ROLE_MO'), 0);
--
