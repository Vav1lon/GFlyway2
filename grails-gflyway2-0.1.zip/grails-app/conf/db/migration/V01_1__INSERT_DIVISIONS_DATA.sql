BEGIN;

INSERT INTO division (code, name) VALUES (1, 'Верхне-Донское управление');
INSERT INTO division (code, name) VALUES (2, 'Волжско-Окское управление');
INSERT INTO division (code, name) VALUES (3, 'Дальневосточное управление');
INSERT INTO division (code, name) VALUES (4, 'Енисейское управление');
INSERT INTO division (code, name) VALUES (5, 'Забайкальское управление');
INSERT INTO division (code, name) VALUES (6, 'Западно-Уральское управление');
INSERT INTO division (code, name) VALUES (7, 'Ленское управление');
INSERT INTO division (code, name) VALUES (8, 'МТУ');
INSERT INTO division (code, name) VALUES (9, 'Нижне-Волжское управление');
INSERT INTO division (code, name) VALUES (10, 'Печорское управление');
INSERT INTO division (code, name) VALUES (11, 'Приволжское управление');
INSERT INTO division (code, name) VALUES (12, 'Приокское управление');
INSERT INTO division (code, name) VALUES (13, 'Сахалинское управление');
INSERT INTO division (code, name) VALUES (14, 'Северо-Восточное управление');
INSERT INTO division (code, name) VALUES (15, 'Северо-Западное управление');
INSERT INTO division (code, name) VALUES (16, 'Северо-Кавказское управление');
INSERT INTO division (code, name) VALUES (17, 'Северо-Уральское управление');
INSERT INTO division (code, name) VALUES (18, 'Кавказское управление');
INSERT INTO division (code, name) VALUES (19, 'Средне-Поволжское управление');
INSERT INTO division (code, name) VALUES (20, 'Уральское управление');
INSERT INTO division (code, name) VALUES (21, 'Центральное управление');
INSERT INTO division (code, name) VALUES (22, 'Сибирское управление');

COMMIT;