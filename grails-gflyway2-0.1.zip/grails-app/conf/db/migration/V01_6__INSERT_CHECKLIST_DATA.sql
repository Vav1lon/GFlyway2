BEGIN;

INSERT INTO checklist (
  item_order
  , name
  , onlyrtn
  , period_id
  , note) VALUES (
  '18.1'
  , 'Наличие плана действий по ликвидации последствий аварийных ситуаций с применением электронного моделирования аварийных ситуаций.'
  , FALSE
  , (SELECT
       id
     FROM reporting_period
     WHERE active = TRUE)
  , null
);

INSERT INTO checklist (
  item_order
  , name
  , onlyrtn
  , period_id
  , note) VALUES (
  '18.2'
  , 'Наличие системы мониторинга состояния системы теплоснабжения.'
  , FALSE
  , (SELECT
       id
     FROM reporting_period
     WHERE active = TRUE)
  , null
);

INSERT INTO checklist (
  item_order
  , name
  , onlyrtn
  , period_id
  , note) VALUES (
  '18.3'
  , 'Наличие механизма оперативно-диспетчерского управления в системе теплоснабжения.'
  , FALSE
  , (SELECT
       id
     FROM reporting_period
     WHERE active = TRUE)
  , null
);

INSERT INTO checklist (
  item_order
  , name
  , onlyrtn
  , period_id
  , note) VALUES (
  '18.4'
  , 'Выполнение требований Правил оценки готовности к отопительному периоду теплоснабжающих и теплосетевых организаций, а также потребителей тепловой энергии.'
  , FALSE
  , (SELECT
       id
     FROM reporting_period
     WHERE active = TRUE)
  , 'Подтверждением выполнения Правил является наличие актов проверки и паспортов готовности к отопительному периоду теплоснабжающих и теплосетевых организаций, а также потребителей тепловой энергии.'
);

COMMIT;