BEGIN;

CREATE SEQUENCE akt_seq;
CREATE SEQUENCE passport_seq;

CREATE TABLE akt (id                  INT8      NOT NULL
  ,               created_employee_id INT8      NOT NULL
  ,               date_created        TIMESTAMP NOT NULL
  ,               district_id         INT8
  ,               file_id             INT8
  ,               last_updated        TIMESTAMP NOT NULL
  ,               municipal_entry_id  INT8
  ,               status              INT4      NOT NULL
  , PRIMARY KEY (id));

CREATE TABLE passport (id                  INT8      NOT NULL
  ,                    created_employee_id INT8      NOT NULL
  ,                    date_created        TIMESTAMP NOT NULL
  ,                    district_id         INT8
  ,                    file_id             INT8      NOT NULL
  ,                    last_updated        TIMESTAMP NOT NULL
  ,                    municipal_entry_id  INT8,
  PRIMARY KEY (id));

ALTER TABLE akt
ADD CONSTRAINT AKT_UPLOAD_FILE_FK
FOREIGN KEY (file_id)
REFERENCES upload_file;

ALTER TABLE akt
ADD CONSTRAINT AKT_MUNICIPAL_ENTRY_FK
FOREIGN KEY (municipal_entry_id)
REFERENCES municipal_entry;

ALTER TABLE akt
ADD CONSTRAINT AKT_EMPLOYEE_FK
FOREIGN KEY (created_employee_id)
REFERENCES employee;

ALTER TABLE akt
ADD CONSTRAINT AKT_DISTRICT_FK
FOREIGN KEY (district_id)
REFERENCES district;

ALTER TABLE passport
ADD CONSTRAINT PASSPORT_UPLOAD_FILE_FK
FOREIGN KEY (file_id)
REFERENCES upload_file;

ALTER TABLE passport
ADD CONSTRAINT PASSPORT_MUNICIPAL_ENTRY_FK
FOREIGN KEY (municipal_entry_id)
REFERENCES municipal_entry;

ALTER TABLE passport
ADD CONSTRAINT PASSPORT_EMPLOYEE_FK
FOREIGN KEY (created_employee_id)
REFERENCES employee;

ALTER TABLE passport
ADD CONSTRAINT PASSPORT_DISTRICT_FK
FOREIGN KEY (district_id)
REFERENCES district;

CREATE INDEX akt_file_index ON akt (file_id);
CREATE INDEX akt_createdEmplyee_index ON akt (created_employee_id);
CREATE INDEX akt_municipalEntry_index ON akt (municipal_entry_id);
CREATE INDEX akt_district_index ON akt (district_id);

CREATE INDEX passport_file_index ON passport (file_id);
CREATE INDEX passport_createdEmplyee_index ON passport (created_employee_id);
CREATE INDEX passport_municipalEntry_index ON passport (municipal_entry_id);
CREATE INDEX passport_district_index ON passport (district_id);

COMMIT;