BEGIN;

INSERT INTO reporting_period (active, begin_year, date_created, end_year, last_updated) VALUES (TRUE, 2013, current_timestamp, 2014, current_timestamp);

COMMIT;