ALTER TABLE employee ADD COLUMN version INT8;
UPDATE employee SET version = 0;
ALTER TABLE employee ALTER COLUMN version SET NOT NULL;
